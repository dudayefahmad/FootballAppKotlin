package com.ahmaddudayef.footballclub.ui.match

import com.ahmaddudayef.footballclub.ui.base.MvpView

/**
 * Created by Ahmad Dudayef on 9/27/2018.
 */
interface MatchMvpView: MvpView