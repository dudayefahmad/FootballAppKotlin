package com.ahmaddudayef.footballclub.ui.match

import com.ahmaddudayef.footballclub.ui.base.MvpPresenter

/**
 * Created by Ahmad Dudayef on 9/27/2018.
 */
interface MatchMvpPresenter<V: MatchMvpView>: MvpPresenter<V>