package com.ahmaddudayef.footballclub.ui.home

import com.ahmaddudayef.footballclub.ui.base.MvpPresenter

/**
 * Created by Ahmad Dudayef on 9/17/2018.
 */
interface HomeMvpPresenter<V: HomeMvpView>: MvpPresenter<V> {

}