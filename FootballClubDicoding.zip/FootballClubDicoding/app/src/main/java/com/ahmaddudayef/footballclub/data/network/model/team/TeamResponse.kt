package com.ahmaddudayef.footballclub.data.network.model.team

/**
 * Created by Ahmad Dudayef on 9/8/2018.
 */

data class TeamResponse(val teams: List<Team>)