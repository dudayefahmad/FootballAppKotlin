package com.ahmaddudayef.footballclub.ui.matches

import com.ahmaddudayef.footballclub.ui.base.MvpPresenter

/**
 * Created by Ahmad Dudayef on 10/17/2018.
 */
interface MatchMvpPresenter<V: MatchMvpView>: MvpPresenter<V> {

}