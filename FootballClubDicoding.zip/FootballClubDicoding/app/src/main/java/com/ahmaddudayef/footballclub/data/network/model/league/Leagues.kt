package com.ahmaddudayef.footballclub.data.network.model.league

/**
 * Created by Ahmad Dudayef on 9/24/2018.
 */
data class Leagues(val leagues: List<League>)