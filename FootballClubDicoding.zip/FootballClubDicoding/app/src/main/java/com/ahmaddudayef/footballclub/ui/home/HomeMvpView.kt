package com.ahmaddudayef.footballclub.ui.home

import android.support.v4.app.Fragment
import com.ahmaddudayef.footballclub.ui.base.MvpView

/**
 * Created by Ahmad Dudayef on 9/16/2018.
 */
interface HomeMvpView: MvpView