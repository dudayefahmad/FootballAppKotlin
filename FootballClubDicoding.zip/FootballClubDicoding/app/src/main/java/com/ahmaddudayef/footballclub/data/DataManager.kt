package com.ahmaddudayef.footballclub.data

import com.ahmaddudayef.footballclub.data.network.ApiHelper

/**
 * Created by Ahmad Dudayef on 9/17/2018.
 */
interface DataManager: ApiHelper