package com.ahmaddudayef.footballclub.ui.favorites

import com.ahmaddudayef.footballclub.ui.base.MvpView

/**
 * Created by Ahmad Dudayef on 10/23/2018.
 */
interface FavoriteMvpView : MvpView