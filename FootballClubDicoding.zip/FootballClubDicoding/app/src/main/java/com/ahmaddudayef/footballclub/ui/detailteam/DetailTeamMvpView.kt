package com.ahmaddudayef.footballclub.ui.detailteam

import com.ahmaddudayef.footballclub.ui.base.MvpView

/**
 * Created by Ahmad Dudayef on 10/18/2018.
 */
interface DetailTeamMvpView : MvpView